"""
test comments for this module
"""

def test_func(param1, param2):
    """
    test function with **reST**

    :param param1: parameter1
    :param param2: parameter2
    :returns: sum of 2 parameters

    other text or reST scripts...
    """
    result = param1 + param2
    return result

def test_func_without_docstring(param):
    return 0

# test
print "hello"
