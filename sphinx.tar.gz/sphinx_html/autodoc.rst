Sphinx AutoDoc
==============

To auto-generate Sphinx docs from python comment:

1. Write python comments in reStructuredText format:

.. code-block:: python
    
    """
    start with comments for the whole module
    """
    
    def test_func(param1, param2):
        """
        test function with **reST**

        :param param1: parameter1
        :param param2: parameter2
        :returns: sum of 2 parameters

        other text or reST scripts...
        """
        result = param1 + param2
        return result

.. warning:: codes outside functions will be excecuted when running "make html", protected these codes by a if __name__ == '__main__' condition or move it into some function


2. In conf.py, add *sys.path.insert(0,os.path.abspath('PATH_TO_THE_PAKAGE'))*, where *PATH_TO_THE_PAKAGE* is the folder of the python modules you want to generate autodoc(may need to add more lines if there are multiple folders)

3. In index.rst(or other .rst files), add following reST scripts at the location you want to display your API docs::

    .. automodule:: MODULE_NAME
       :members:
       :undoc-members:
        
where **MODULE_NAME** is the filename you want auto doc.

4. run **make html** and it should work, the result should be like this:

.. automodule:: autodoc_test
   :members:
   :undoc-members:
